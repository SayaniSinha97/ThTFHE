#pragma once

#include "tfhe/common.h"

Torus32 gaussian32(double mean, double sd);
Torus32 dtot32(double d);