#pragma once

int get_cycle_count();