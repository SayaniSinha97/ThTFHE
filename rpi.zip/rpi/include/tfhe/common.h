#pragma once

#include <stdint.h>

typedef int32_t Torus32;

